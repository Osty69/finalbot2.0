import json
import telebot
from telebot import types
import bs4
import random
import requests
from goro import first, second, second_add, third
import BotGames
from menuBot import Menu

bot = telebot.TeleBot('5228932255:AAE8uXyumID0x2ZGFoSbgbA_sVzJGo28Lr8')
game21 = None
# value = ''
# old_value = ''


@bot.message_handler(commands="start")
def command(message, res=False):
    txt_message = f"Привет, {message.from_user.first_name}! Я тестовый бот для курса программирования на языке Python"
    bot.send_message(message.chat.id, text=txt_message, reply_markup=Menu.getMenu("Главное меню").markup)


@bot.message_handler(content_types=['text'])
def get_text_messages(message):
    global game21

    chat_id = message.chat.id
    ms_text = message.text

    result = goto_menu(chat_id, ms_text)
    if result == True:
        return

    if Menu.cur_menu != None and ms_text in Menu.cur_menu.buttons:

        if ms_text == "Помощь":
            send_help(chat_id)

        elif ms_text == "Прислать фильм":
            send_film(bot, chat_id)

        elif ms_text == "Прислать собаку":
            bot.send_message(chat_id, text="🐶")

        # elif ms_text == 'Калькулятор':
        #     global value
        #     if value == '':
        #         bot.send_message(chat_id, '0', send_cal(chat_id))
        #     else:
        #         bot.send_message(chat_id, value, send_cal(chat_id))

        elif ms_text == "Гороскоп":
            bot.send_message(chat_id, text=get_goro(chat_id))

        elif ms_text == 'Песня дня':
            bot.send_message(chat_id, get_song())

        elif ms_text == "Прислать анекдот":
            bot.send_message(chat_id, text=get_anekdot())

        elif ms_text == "Карту!":
            if game21 == None:
                goto_menu(chat_id, "Выход")
                return

            text_game = game21.get_cards(1)
            bot.send_media_group(chat_id, media=getMediaCards(game21))
            bot.send_message(chat_id, text=text_game)

            if game21.status != None:
                goto_menu(chat_id, "Выход")
                return

        elif ms_text == "Стоп!":
            game21 = None
            goto_menu(chat_id, "Выход")
            return


def goto_menu(chat_id, name_menu):
    if name_menu == "Выход" and Menu.cur_menu != None and Menu.cur_menu.parent != None:
        target_menu = Menu.getMenu(Menu.cur_menu.parent.name)
    else:
        target_menu = Menu.getMenu(name_menu)

    if target_menu != None:
        bot.send_message(chat_id, text=target_menu.name, reply_markup=target_menu.markup)

        if target_menu.name == "Игра в 21":
            bot.send_message(chat_id,
                             'Стоимость карт в очках: туз — 11 очков, король — 4 очка, дама — 3 очка, валет — 2 очка, остальные — по номиналу.')
            global game21
            game21 = BotGames.Game21()
            text_game = game21.get_cards(2)
            bot.send_media_group(chat_id, media=getMediaCards(game21))
            bot.send_message(chat_id, text=text_game)

        return True
    else:
        return False


# def send_cal(chat_id):
#     global value, old_value
#     keyboard = telebot.types.InlineKeyboardMarkup()
#     if value == '':
#         bot.send_message(chat_id, '0', reply_markup=keyboard)
#     else:
#         bot.send_message(chat_id, reply_markup=keyboard)
#     keyboard.row(telebot.types.InlineKeyboardButton(' ', callback_data='no'),
#                  telebot.types.InlineKeyboardButton('C', callback_data='C'),
#                  telebot.types.InlineKeyboardButton('<=', callback_data='<='),
#                  telebot.types.InlineKeyboardButton('/', callback_data='/'))
#     keyboard.row(telebot.types.InlineKeyboardButton('7', callback_data='7'),
#                  telebot.types.InlineKeyboardButton('8', callback_data='8'),
#                  telebot.types.InlineKeyboardButton('9', callback_data='9'),
#                  telebot.types.InlineKeyboardButton('*', callback_data='*'))
#     keyboard.row(telebot.types.InlineKeyboardButton('4', callback_data='4'),
#                  telebot.types.InlineKeyboardButton('5', callback_data='5'),
#                  telebot.types.InlineKeyboardButton('6', callback_data='6'),
#                  telebot.types.InlineKeyboardButton('-', callback_data='-'))
#     keyboard.row(telebot.types.InlineKeyboardButton('1', callback_data='1'),
#                  telebot.types.InlineKeyboardButton('2', callback_data='2'),
#                  telebot.types.InlineKeyboardButton('3', callback_data='3'),
#                  telebot.types.InlineKeyboardButton('+', callback_data='+'))
#     keyboard.row(telebot.types.InlineKeyboardButton(' ', callback_data='no'),
#                  telebot.types.InlineKeyboardButton('0', callback_data='0'),
#                  telebot.types.InlineKeyboardButton(',', callback_data='.'),
#                  telebot.types.InlineKeyboardButton('=', callback_data='='))
#     bot.send_message(chat_id, text='0', reply_markup=keyboard)
#
#     @bot.callback_query_handler(func=lambda call: True)
#     def callback_func(query):
#         global value, old_value
#         data = query.data
#         if query.data == 'no':
#             pass
#         elif query.data == 'C':
#             value = ''
#         elif query.data == '=':
#             value = str(eval(value))
#         else:
#             value += data
#
#         if value != old_value:
#             if value == '':
#                 bot.edit_message_text(chat_id, text='0', reply_markup=keyboard)
#             else:
#                 bot.edit_message_text(chat_id, text=value, reply_markup=keyboard)
#         old_value = value


def get_song():
    array_songs = []
    req_son = requests.get('https://power.gybka.com/random')
    if req_son.status_code == 200:
        soup = bs4.BeautifulSoup(req_son.text, "html.parser")
        result_find = soup.select('.playlist-title')
        for result in result_find:
            array_songs.append(result.getText().strip())
    if len(array_songs) > 0:
        return array_songs[0]
    else:
        return ""


def getMediaCards(game21):
    medias = []
    for url in game21.arr_cards_URL:
        medias.append(types.InputMediaPhoto(url))
    return medias


def get_goro(chat_id):
    bot.send_message(chat_id, "Сейчас я расскажу тебе гороскоп на сегодня.")
    keyboard = types.InlineKeyboardMarkup()
    key_oven = types.InlineKeyboardButton(text='Овен', callback_data='zodiac')
    keyboard.add(key_oven)
    key_telec = types.InlineKeyboardButton(text='Телец', callback_data='zodiac')
    keyboard.add(key_telec)
    key_bliznecy = types.InlineKeyboardButton(text='Близнецы', callback_data='zodiac')
    keyboard.add(key_bliznecy)
    key_rak = types.InlineKeyboardButton(text='Рак', callback_data='zodiac')
    keyboard.add(key_rak)
    key_lev = types.InlineKeyboardButton(text='Лев', callback_data='zodiac')
    keyboard.add(key_lev)
    key_deva = types.InlineKeyboardButton(text='Дева', callback_data='zodiac')
    keyboard.add(key_deva)
    key_vesy = types.InlineKeyboardButton(text='Весы', callback_data='zodiac')
    keyboard.add(key_vesy)
    key_scorpion = types.InlineKeyboardButton(text='Скорпион', callback_data='zodiac')
    keyboard.add(key_scorpion)
    key_strelec = types.InlineKeyboardButton(text='Стрелец', callback_data='zodiac')
    keyboard.add(key_strelec)
    key_kozerog = types.InlineKeyboardButton(text='Козерог', callback_data='zodiac')
    keyboard.add(key_kozerog)
    key_vodoley = types.InlineKeyboardButton(text='Водолей', callback_data='zodiac')
    keyboard.add(key_vodoley)
    key_ryby = types.InlineKeyboardButton(text='Рыбы', callback_data='zodiac')
    keyboard.add(key_ryby)
    bot.send_message(chat_id, text='Выбери свой знак зодиака', reply_markup=keyboard)


@bot.callback_query_handler(func=lambda call: True)
def callback_worker(call):
    if call.data == "zodiac":
        msg = random.choice(first) + ' ' + random.choice(second) + ' ' + random.choice(
            second_add) + ' ' + random.choice(third)
        bot.send_message(call.message.chat.id, msg)


def send_help(chat_id):
    global bot
    bot.send_message(chat_id, "Автор: Даня Останин")
    key1 = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton(text="Напиши мне", url="https://t.me/ostych")
    key1.add(btn1)
    img = open('channels4_profile.jpg', 'rb')
    bot.send_photo(chat_id, img, reply_markup=key1)


def send_film(bot, chat_id):
    film = get_randomFilm()
    info_str = f"{film['Наименование']}"
    bot.send_photo(chat_id, photo=film['Обложка_url'], caption=info_str, parse_mode='HTML')


def get_randomFilm():
    url = 'https://randomfilm.ru/'
    infoFilm = {}
    req_film = requests.get(url)
    soup = bs4.BeautifulSoup(req_film.text, "html.parser")
    result_find = soup.find('div', align="center", style="width: 100%")
    infoFilm["Наименование"] = result_find.find("h2").getText()
    images = []
    for img in result_find.findAll('img'):
        images.append(url + img.get('src'))
    infoFilm["Обложка_url"] = images[0]

    return infoFilm


def get_anekdot():
    array_anekdots = []
    req_anek = requests.get('http://anekdotme.ru/random')
    soup = bs4.BeautifulSoup(req_anek.text, "html.parser")
    result_find = soup.select('.anekdot_text')
    for result in result_find:
        array_anekdots.append(result.getText().strip())
    return array_anekdots[0]


bot.polling(none_stop=True, interval=0)

print()
